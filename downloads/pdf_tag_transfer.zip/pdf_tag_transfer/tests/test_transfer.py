import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pikepdf as q
import pymupdf as fitz
import pytest
from transfer_core import Transfer, Document


def pair(tmp_path, changed=False):
    original=tmp_path/'original.pdf'; source=tmp_path/'source.pdf'
    pdf=q.new(); page=pdf.add_blank_page(page_size=(400,400))
    font=pdf.make_indirect(q.Dictionary(Type=q.Name.Font,Subtype=q.Name.Type1,BaseFont=q.Name.Helvetica))
    page.obj.Resources=q.Dictionary(Font=q.Dictionary(F1=font))
    drawing=b'BT /F1 20 Tf 30 340 Td (First) Tj 0 -30 Td (Second) Tj ET'
    page.obj.Contents=pdf.make_stream(drawing); pdf.save(original)
    root=pdf.make_indirect(q.Dictionary(Type=q.Name.StructTreeRoot))
    doc=pdf.make_indirect(q.Dictionary(Type=q.Name.StructElem,S=q.Name.Document,P=root))
    tags=[pdf.make_indirect(q.Dictionary(Type=q.Name.StructElem,S=q.Name.P,P=doc,Pg=page.obj,K=i,Alt=f'Alt {i}',ID=f'id{i}',A=q.Dictionary(O=q.Name.Table,RowSpan=1))) for i in range(2)]
    doc.K=q.Array(tags); root.K=doc; root.ParentTree=pdf.make_indirect(q.Dictionary(Nums=q.Array([0,q.Array(tags)])))
    pdf.Root.StructTreeRoot=root; page.obj.StructParents=0
    content=b'BT /F1 20 Tf 30 340 Td /P <</MCID 0>> BDC (First) Tj EMC 0 -30 Td /P <</MCID 1>> BDC (Second) Tj EMC ET'
    if changed:content=content.replace(b'First',b'Other')
    page.obj.Contents=pdf.make_stream(content); pdf.save(source);pdf.close()
    return original,source


def test_precise_text_boundaries_metadata_and_save(tmp_path):
    original,source=pair(tmp_path); before=original.read_bytes(); s=Transfer(original,source)
    assert s.step()==0 and s.states==['Transferred']
    assert len(s.links)==2 and not s.unresolved()
    out=tmp_path/'out.pdf'; s.save(out)
    d=Document(out)
    assert [t.role for t in d.tags]==['Document','P','P']
    assert d.tags[1].alt=='Alt 0'
    assert d.selection(1,0)[1]=='First'
    assert d.selection(2,0)[1]=='Second'
    with q.open(out) as pdf:
        assert len(q.NumberTree(pdf.Root.StructTreeRoot.ParentTree)[0])==2
        assert len(pdf.Root.StructTreeRoot.IDTree.Names)==4
    assert original.read_bytes()==before
    with pytest.raises(ValueError):s.save(original)
    s.undo(); assert not s.links and s.states==['Pending']
    s.step();assert len(s.links)==2
    d.close();s.close()


def test_changed_artwork_is_flagged_without_transfer(tmp_path):
    original,source=pair(tmp_path,True);s=Transfer(original,source)
    s.step();assert s.states==['Needs review'] and not s.links
    assert len(s.unresolved())==2
    s.close()


def test_duplicate_content_ownership_flagged(tmp_path):
    original,source=pair(tmp_path)
    with q.open(source,allow_overwriting_input=True) as pdf:
        pdf.Root.StructTreeRoot.K.K[1].K=0;pdf.save(source)
    s=Transfer(original,source);s.step()
    assert s.states==['Needs review'];assert not s.links;s.close()


def test_tagged_base_rejected(tmp_path):
    original,source=pair(tmp_path)
    with pytest.raises(ValueError,match='original'):Transfer(source,source)


def test_hard_link_input_protected(tmp_path):
    original,source=pair(tmp_path);s=Transfer(original,source)
    alias=tmp_path/'alias.pdf';alias.hardlink_to(original)
    with pytest.raises(ValueError):s.save(alias)
    s.close()


def test_nested_mcid_rejected(tmp_path):
    original,source=pair(tmp_path)
    with q.open(source,allow_overwriting_input=True) as pdf:
        content=pdf.pages[0].obj.Contents.read_bytes()
        pdf.pages[0].obj.Contents=pdf.make_stream(b'/Span <</MCID 8>> BDC '+content+b' EMC')
        pdf.save(source)
    s=Transfer(original,source);s.step()
    assert s.states==['Needs review'] and not s.links;s.close()


def test_forms_flagged(tmp_path):
    original,source=pair(tmp_path)
    with q.open(source,allow_overwriting_input=True) as pdf:
        form=pdf.make_stream(b'');form.Type=q.Name.XObject;form.Subtype=q.Name.Form;form.BBox=q.Array([0,0,10,10]);form.StructParents=10
        pdf.pages[0].obj.Resources.XObject=q.Dictionary(Fm=form);pdf.save(source)
    s=Transfer(original,source);s.step()
    assert s.states==['Needs review'] and 'Form' in s.messages[0];s.close()


def test_duplicate_ids_rejected(tmp_path):
    original,source=pair(tmp_path)
    with q.open(source,allow_overwriting_input=True) as pdf:
        pdf.Root.StructTreeRoot.K.K[1].ID='id0';pdf.save(source)
    with pytest.raises(ValueError,match='Duplicate source tag IDs'):Transfer(original,source)


def test_parenttree_fallback_for_missing_page(tmp_path):
    original,source=pair(tmp_path)
    with q.open(source,allow_overwriting_input=True) as pdf:
        for tag in pdf.Root.StructTreeRoot.K.K: del tag.Pg
        pdf.save(source)
    s=Transfer(original,source);s.step();assert s.states==['Transferred']
    out=tmp_path/'fallback.pdf';s.save(out);d=Document(out)
    assert d.selection(1,0)[1]=='First' and d.selection(2,0)[1]=='Second'
    d.close();s.close()
